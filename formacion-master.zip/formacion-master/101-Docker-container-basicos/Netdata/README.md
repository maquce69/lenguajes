NETDATA CON Docker:
https://github.com/netdata/netdata/tree/master/packaging/docker#install-netdata-with-docker